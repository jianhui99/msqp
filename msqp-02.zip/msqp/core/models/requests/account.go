package requests

const (
	None = iota
	Account
	WeiXin
	MobilePhone
)
