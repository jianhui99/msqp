package base

type UnionBase interface {
	DismissRoom(roomId string)
}
